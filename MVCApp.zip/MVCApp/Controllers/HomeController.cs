﻿using MVCApp.DataAccess;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace MVCApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase CustomerImage, HttpPostedFileBase VerificationDocument)
        {
            //using DB to store 
            using (var db = new CustomerVerificationContext())
            {
                //variables to store in DB
                var customerImage = String.Empty;
                var documentImage = String.Empty;

                int permittedSizeInBytes = 40000;//4mb

                //respective directories to seprate photos and documents snapshots
                string customerImageDir = Server.MapPath("~/Uploads/Photos");
                string documetnImageDir = Server.MapPath("~/Uploads/Documents");

                //creating directories
                if (!Directory.Exists(customerImageDir))
                {
                    Directory.CreateDirectory(customerImageDir);
                }
                if (!Directory.Exists(documetnImageDir))
                {
                    Directory.CreateDirectory(documetnImageDir);
                }
             
                if (CustomerImage != null)
                {
                    if (CustomerImage.ContentLength < permittedSizeInBytes)
                    {
                        ViewBag.Message = "File cannot be more than 4MB";
                    }

                   string fileExtension = Path.GetExtension(CustomerImage.FileName);
                   Guid fileGuid = Guid.NewGuid();
                   //uploading file to respective directory
                   var path = Path.Combine(customerImageDir, fileGuid.ToString() + fileExtension);
                   CustomerImage.SaveAs(path + fileExtension);
                   //store in db
                   customerImage = fileGuid.ToString() + fileExtension;
                   ViewBag.Message = "Image uploaded successfully.";
                }

                if (VerificationDocument != null)
                {
                    if (VerificationDocument.ContentLength < permittedSizeInBytes)
                    {
                        ViewBag.Message = "File cannot be more than 4MB";
                    }

                    string fileExtension = Path.GetExtension(VerificationDocument.FileName);
                    Guid fileGuid = Guid.NewGuid();
                    //uploading file to respective directory
                    var path = Path.Combine(documetnImageDir,fileGuid.ToString() + fileExtension);
                    VerificationDocument.SaveAs(path + fileExtension);
                    //store in db
                    documentImage = fileGuid.ToString() + fileExtension;
                    ViewBag.Message = "Document uploaded successfully.";                 
                }
                //saving changes to db
                var saveToDb = new verification() { Photo = customerImage, C_Document = documentImage };
                db.verification.Add(saveToDb);
                db.SaveChanges();
                var result = GetResult(customerImage, documentImage);
                return View();
            }
        }

        public bool GetResult(string customerImage,string documentImage)
        {
            var URL = "http://52.173.93.94/FaceDetectionService/";

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(URL);
                var uri = String.Concat("api/Face/CompareFacialIdentity?faceImage=" + customerImage + "&documentImage=" + documentImage); 
                var postTask = client.GetAsync(uri);
                postTask.Wait();

                var result = postTask.Result;
            }

            return true;
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}